// ============================================================================
// OpenLVET 自定义背景与透明毛玻璃特效插件 (Custom Background & Glassmorphism)
// ============================================================================
(function() {
  var PRESET_WALLPAPERS = {
    "aurora-galaxy": {
      label: "极地深空星轨",
      url: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=2560&auto=format&fit=crop",
      preview: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=500&auto=format&fit=crop"
    },
    "cyber-night": {
      label: "赛博暗夜霓虹",
      url: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=2560&auto=format&fit=crop",
      preview: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=500&auto=format&fit=crop"
    },
    "sunset-ocean": {
      label: "暮光海平面",
      url: "https://images.unsplash.com/photo-1518837695005-2083093ee35b?q=80&w=2560&auto=format&fit=crop",
      preview: "https://images.unsplash.com/photo-1518837695005-2083093ee35b?q=80&w=500&auto=format&fit=crop"
    },
    "misty-forest": {
      label: "治愈森林雾霭",
      url: "https://images.unsplash.com/photo-1448375240586-882707db888b?q=80&w=2560&auto=format&fit=crop",
      preview: "https://images.unsplash.com/photo-1448375240586-882707db888b?q=80&w=500&auto=format&fit=crop"
    },
    "fluid-glow": {
      label: "幻彩流体光晕",
      url: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2560&auto=format&fit=crop",
      preview: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=500&auto=format&fit=crop"
    },
    "dark-obsidian": {
      label: "极简黑曜石",
      url: "linear-gradient(135deg, #090a0f 0%, #101524 45%, #081b2c 100%)",
      preview: "linear-gradient(135deg, #090a0f 0%, #101524 45%, #081b2c 100%)",
      isGradient: true
    }
  };

  var STYLE_ID = "openlvet-custom-bg-glass-style";
  var BG_LAYER_ID = "openlvet-custom-bg-layer";

  function applyGlassmorphism(config) {
    if (typeof document === 'undefined') return;

    var enabled = config.enabled !== false;
    var html = document.documentElement;

    if (!enabled) {
      html.classList.remove("openlvet-glass-active", "glass-border-enabled");
      var existingBg = document.getElementById(BG_LAYER_ID);
      if (existingBg) existingBg.style.display = "none";
      return;
    }

    html.classList.add("openlvet-glass-active");
    if (config.glassBorder !== false) {
      html.classList.add("glass-border-enabled");
    } else {
      html.classList.remove("glass-border-enabled");
    }

    // 1. 设置 CSS 变量
    var glassBlur = typeof config.glassBlur === 'number' ? config.glassBlur : 18;
    var glassOpacity = typeof config.glassOpacity === 'number' ? (config.glassOpacity / 100) : 0.55;
    var glassSaturation = typeof config.glassSaturation === 'number' ? config.glassSaturation : 160;

    html.style.setProperty("--glass-blur-radius", glassBlur + "px");
    html.style.setProperty("--glass-panel-opacity", String(glassOpacity));
    html.style.setProperty("--glass-saturation", glassSaturation + "%");

    // 2. 注入/更新全局样式表
    var styleEl = document.getElementById(STYLE_ID);
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = STYLE_ID;
      document.head.appendChild(styleEl);
    }

    styleEl.textContent = [
      "html.openlvet-glass-active,",
      "html.openlvet-glass-active body {",
      "  background-color: transparent !important;",
      "}",
      "",
      "/* 面板、顶栏、侧边栏及弹窗毛玻璃化 */",
      "html.openlvet-glass-active .panel,",
      "html.openlvet-glass-active aside,",
      "html.openlvet-glass-active header,",
      "html.openlvet-glass-active nav,",
      "html.openlvet-glass-active [role='dialog'],",
      "html.openlvet-glass-active [data-radix-popper-content-wrapper] > div,",
      "html.openlvet-glass-active .bg-card:not(#openlvet-custom-bg-layer *),",
      "html.openlvet-glass-active .bg-popover:not(#openlvet-custom-bg-layer *),",
      "html.openlvet-glass-active .bg-background:not(#openlvet-custom-bg-layer *) {",
      "  background-color: hsla(var(--background) / var(--glass-panel-opacity, 0.55)) !important;",
      "  backdrop-filter: blur(var(--glass-blur-radius, 18px)) saturate(var(--glass-saturation, 160%)) !important;",
      "  -webkit-backdrop-filter: blur(var(--glass-blur-radius, 18px)) saturate(var(--glass-saturation, 160%)) !important;",
      "  transition: background-color 0.3s cubic-bezier(0.16, 1, 0.3, 1), backdrop-filter 0.3s ease;",
      "}",
      "",
      "/* 玻璃高光边框规范 */",
      "html.openlvet-glass-active.glass-border-enabled .panel,",
      "html.openlvet-glass-active.glass-border-enabled aside,",
      "html.openlvet-glass-active.glass-border-enabled header,",
      "html.openlvet-glass-active.glass-border-enabled [role='dialog'] {",
      "  border-color: rgba(255, 255, 255, 0.12) !important;",
      "}",
      "",
      ".dark html.openlvet-glass-active.glass-border-enabled .panel,",
      ".dark html.openlvet-glass-active.glass-border-enabled aside,",
      ".dark html.openlvet-glass-active.glass-border-enabled header,",
      ".dark html.openlvet-glass-active.glass-border-enabled [role='dialog'] {",
      "  border-color: rgba(255, 255, 255, 0.14) !important;",
      "}",
      "",
      "/* 面板悬浮轻微投影 */",
      "html.openlvet-glass-active .panel {",
      "  box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.35) !important;",
      "}"
    ].join("\n");

    // 3. 注入/更新背景层
    var bgLayer = document.getElementById(BG_LAYER_ID);
    if (!bgLayer) {
      bgLayer = document.createElement("div");
      bgLayer.id = BG_LAYER_ID;
      bgLayer.style.cssText = "position: fixed; inset: 0; z-index: -9999; pointer-events: none; overflow: hidden; transform: translateZ(0); transition: filter 0.3s ease, opacity 0.4s ease;";
      document.body.insertBefore(bgLayer, document.body.firstChild);
    }

    bgLayer.style.display = "block";
    var bgType = config.bgType || "preset";
    var bgUrl = "";
    var isGradient = false;

    if (bgType === "url" && config.customBgUrl) {
      bgUrl = config.customBgUrl.trim();
    } else if (bgType === "gradient") {
      isGradient = true;
      bgUrl = "radial-gradient(at 10% 20%, rgba(59, 130, 246, 0.45) 0px, transparent 50%), radial-gradient(at 90% 10%, rgba(236, 72, 153, 0.45) 0px, transparent 50%), radial-gradient(at 50% 80%, rgba(16, 185, 129, 0.4) 0px, transparent 50%), #0b0f19";
    } else {
      var presetKey = config.presetWallpaper || "aurora-galaxy";
      var preset = PRESET_WALLPAPERS[presetKey] || PRESET_WALLPAPERS["aurora-galaxy"];
      bgUrl = preset.url;
      isGradient = !!preset.isGradient;
    }

    var brightness = typeof config.bgBrightness === 'number' ? config.bgBrightness / 100 : 0.55;
    var blurPx = typeof config.bgBlur === 'number' ? config.bgBlur : 0;

    if (isGradient) {
      bgLayer.style.background = bgUrl;
      bgLayer.style.backgroundSize = "cover";
    } else {
      bgLayer.style.background = "url('" + bgUrl + "') no-repeat center center";
      bgLayer.style.backgroundSize = "cover";
    }

    bgLayer.style.filter = "brightness(" + brightness + ") blur(" + blurPx + "px)";
    bgLayer.style.transform = blurPx > 0 ? "scale(1.04)" : "scale(1)";
  }

  function cleanup() {
    if (typeof document === 'undefined') return;
    var html = document.documentElement;
    html.classList.remove("openlvet-glass-active", "glass-border-enabled");
    html.style.removeProperty("--glass-blur-radius");
    html.style.removeProperty("--glass-panel-opacity");
    html.style.removeProperty("--glass-saturation");

    var styleEl = document.getElementById(STYLE_ID);
    if (styleEl && styleEl.parentNode) styleEl.parentNode.removeChild(styleEl);

    var bgLayer = document.getElementById(BG_LAYER_ID);
    if (bgLayer && bgLayer.parentNode) bgLayer.parentNode.removeChild(bgLayer);
  }

  module.exports = {
    manifest: {
  "id": "custom-bg-glass",
  "name": "自定义背景与透明毛玻璃特效",
  "version": "1.0.0",
  "description": "为 OpenLVET 带来沉浸式自定义全景背景，并将编辑器面板、导航栏与工具栏自动变换为通透高级的毛玻璃磨砂质感 (Glassmorphism)。",
  "author": "OpenLVET Open Source Team",
  "category": "visuals",
  "tags": [
    "背景",
    "毛玻璃",
    "Glassmorphism",
    "个性化",
    "UI主题",
    "极简美学"
  ],
  "homepage": "https://github.com/Polonium-salts/OpenLVET",
  "builtin": true,
  "configSchema": [
    {
      "key": "enabled",
      "label": "启用全景背景与毛玻璃特效",
      "description": "开启后自动渲染全景背景并将所有面板转为透光毛玻璃",
      "type": "boolean",
      "group": "核心开关",
      "default": true
    },
    {
      "key": "bgType",
      "label": "背景呈现模式",
      "description": "选择全景背景的数据来源",
      "type": "select",
      "group": "全景背景设置",
      "default": "preset",
      "options": [
        {
          "label": "🖼️ 精选高清壁纸 (Curated Wallpaper)",
          "value": "preset"
        },
        {
          "label": "🔗 自定义图片外链 (Image URL)",
          "value": "url"
        },
        {
          "label": "🎨 炫彩流体流动渐变 (Mesh Gradient)",
          "value": "gradient"
        }
      ]
    },
    {
      "key": "presetWallpaper",
      "label": "精选壁纸库",
      "description": "快速应用内置经过调色适配的高清大片壁纸",
      "type": "select",
      "group": "全景背景设置",
      "default": "aurora-galaxy",
      "options": [
        {
          "label": "🌌 极地深空星轨 (Aurora Galaxy)",
          "value": "aurora-galaxy"
        },
        {
          "label": "🌃 赛博暗夜霓虹 (Cyber Night)",
          "value": "cyber-night"
        },
        {
          "label": "🌅 暮光海平面延时 (Sunset Ocean)",
          "value": "sunset-ocean"
        },
        {
          "label": "🌿 治愈森林雾霭 (Misty Forest)",
          "value": "misty-forest"
        },
        {
          "label": "🟣 幻彩流体光晕 (Fluid Glow)",
          "value": "fluid-glow"
        },
        {
          "label": "🖤 极简黑曜石深色 (Dark Obsidian)",
          "value": "dark-obsidian"
        }
      ]
    },
    {
      "key": "customBgUrl",
      "label": "自定义图片直接链接",
      "description": "输入以 http/https 开头的图片外链（支持 jpg/png/webp）",
      "type": "string",
      "group": "全景背景设置",
      "placeholder": "例如: https://images.unsplash.com/photo-...",
      "default": ""
    },
    {
      "key": "bgBrightness",
      "label": "背景明亮度",
      "description": "调暗背景使前台时间线轨道与剪辑画面保持清晰高对比",
      "type": "number",
      "group": "全景背景设置",
      "min": 15,
      "max": 100,
      "step": 5,
      "default": 55
    },
    {
      "key": "bgBlur",
      "label": "背景景深虚化",
      "description": "为背景图本身添加轻微虚化景深，强化层次感",
      "type": "number",
      "group": "全景背景设置",
      "min": 0,
      "max": 40,
      "step": 2,
      "default": 0
    },
    {
      "key": "glassBlur",
      "label": "UI 面板毛玻璃模糊半径",
      "description": "面板背后的磨砂模糊强弱（数值越大越柔和）",
      "type": "number",
      "group": "毛玻璃磨砂规范",
      "min": 4,
      "max": 40,
      "step": 2,
      "default": 18
    },
    {
      "key": "glassOpacity",
      "label": "UI 面板底色透光度",
      "description": "面板背景的不透明度百分比（越低越通透）",
      "type": "number",
      "group": "毛玻璃磨砂规范",
      "min": 15,
      "max": 90,
      "step": 5,
      "default": 55
    },
    {
      "key": "glassSaturation",
      "label": "毛玻璃色彩饱和度增强",
      "description": "透光折射时增强背景鲜艳度，呈现 visionOS 式晶莹质感",
      "type": "number",
      "group": "毛玻璃磨砂规范",
      "min": 100,
      "max": 220,
      "step": 10,
      "default": 160
    },
    {
      "key": "glassBorder",
      "label": "高光玻璃微边框",
      "description": "为面板边缘添加 1px 半透明微高光，勾勒精细轮廓",
      "type": "boolean",
      "group": "毛玻璃磨砂规范",
      "default": true
    }
  ],
  "defaultConfig": {
    "enabled": true,
    "bgType": "preset",
    "presetWallpaper": "aurora-galaxy",
    "customBgUrl": "",
    "bgBrightness": 55,
    "bgBlur": 0,
    "glassBlur": 18,
    "glassOpacity": 55,
    "glassSaturation": 160,
    "glassBorder": true
  },
  "readme": "# 🎨 自定义背景与透明毛玻璃特效 (Custom Background & Glassmorphism)\n\n> OpenLVET 官方扩展插件 · 开启极简轻奢的个性化工作区与透明毛玻璃视觉\n\n---\n\n## ✨ 核心特性\n\n- **🖼️ 沉浸式全屏背景**：\n  - 内置多款精挑细选的 4K 壁纸（赛博霓虹、深空银河、暮光海浪、森林雾霭等）；\n  - 支持任意自定义图片直链（Unsplash、Pexels 等）；\n  - 支持丝滑动态流体渐变；\n  - 自由调节背景明亮度（防止背景过亮干扰主预览画面）与景深虚化。\n- **🔮 全局 UI 自动透明毛玻璃化**：\n  - 自动将左侧资产栏、顶部 Header、时间线面板、属性栏及浮动弹窗重构为透明磨砂材质；\n  - 基于真实 CSS `backdrop-filter: blur() saturate()` 光学折射渲染；\n  - 提供精致的高光透光微边框（Glass Highlight Border）；\n  - 实时响应配置调节，无须重启刷新页面。\n- **⚙️ 闭环交互规范**：\n  - 采用标准的受控两列式自动排版；\n  - 左侧面板支持一键快捷切换壁纸与实时滑块微调；\n  - 右上角直达齿轮（`⚙`）一键直通完整配置面板。\n"
},

    activate: function(context) {
      var initialConfig = Object.assign({}, context.plugin.defaultConfig || {}, context.config.getAll());
      applyGlassmorphism(initialConfig);

      var unlisten = context.config.onChange(function(newConfig) {
        applyGlassmorphism(newConfig);
      });
      context.addDisposable(unlisten);
      context.addDisposable(cleanup);

      // 注册左侧资产导航栏快捷控制面板
      context.panels.registerAssetTab({
        id: "custom-bg-glass",
        label: "背景玻璃",
        icon: "🎨",
        order: 38,
        render: function(props) {
          return React.createElement(CustomBgGlassPanel, {
            pluginContext: context,
            manifest: props.plugin
          });
        }
      });

      // 注册动作与快捷菜单
      context.actions.registerAction({
        id: "custom-bg-glass:toggle",
        description: "切换全景背景与毛玻璃特效",
        handler: function() {
          var cur = context.config.get("enabled", true);
          context.config.set("enabled", !cur);
          if (context.ui && context.ui.showToast) {
            context.ui.showToast(!cur ? "✨ 已开启全景背景与毛玻璃特效" : "已暂停毛玻璃效果", { type: "info" });
          }
        }
      });

      context.header.registerHeaderItem({
        id: "custom-bg-glass-btn",
        icon: "🎨",
        tooltip: "自定义背景与毛玻璃设置",
        position: "right",
        order: 15,
        onClick: function() {
          if (context.ui && context.ui.openPluginSettings) {
            context.ui.openPluginSettings(context.plugin.id);
          }
        }
      });
    },

    deactivate: function(context) {
      cleanup();
    },

    onConfigChange: function(newConfig, context) {
      applyGlassmorphism(newConfig);
    }
  };

  // ============================================================================
  // React 运行时面板组件：CustomBgGlassPanel
  // ============================================================================
  function CustomBgGlassPanel(props) {
    var React = (typeof window !== 'undefined' ? window.React : null) || (typeof React !== 'undefined' ? React : null) || (typeof require !== 'undefined' ? require('react') : null);
    if (!React) return null;

    var context = props.pluginContext;
    var useState = React.useState;
    var useEffect = React.useEffect;

    var [config, setConfig] = useState(function() {
      return Object.assign({}, context.plugin.defaultConfig || {}, context.config.getAll());
    });

    useEffect(function() {
      var unsub = context.config.onChange(function(latest) {
        setConfig(Object.assign({}, context.plugin.defaultConfig || {}, latest));
      });
      return unsub;
    }, []);

    var updateField = function(key, val) {
      context.config.set(key, val);
    };

    var presetsList = [
      { id: "aurora-galaxy", name: "极地星轨", url: PRESET_WALLPAPERS["aurora-galaxy"].preview },
      { id: "cyber-night", name: "赛博暗夜", url: PRESET_WALLPAPERS["cyber-night"].preview },
      { id: "sunset-ocean", name: "暮光海面", url: PRESET_WALLPAPERS["sunset-ocean"].preview },
      { id: "misty-forest", name: "治愈森林", url: PRESET_WALLPAPERS["misty-forest"].preview },
      { id: "fluid-glow", name: "流体光晕", url: PRESET_WALLPAPERS["fluid-glow"].preview },
      { id: "dark-obsidian", name: "极简黑曜", gradient: PRESET_WALLPAPERS["dark-obsidian"].preview }
    ];

    return React.createElement(
      "div",
      { className: "flex flex-col h-full bg-background select-none text-foreground font-sans" },

      // 宿主标准 Header
      React.createElement(
        "header",
        { className: "px-3.5 py-2.5 border-b border-border/50 flex items-center justify-between bg-card/30 shrink-0 backdrop-blur-sm" },
        React.createElement(
          "div",
          { className: "flex items-center gap-2 min-w-0" },
          React.createElement("span", { className: "text-base leading-none" }, "🎨"),
          React.createElement("h3", { className: "text-xs font-bold truncate text-foreground" }, "背景与毛玻璃"),
          React.createElement(
            "span",
            { className: "text-[10px] px-1.5 py-0.2 rounded-full font-mono font-medium " + (config.enabled ? "bg-primary/15 text-primary border border-primary/25" : "bg-muted text-muted-foreground border") },
            config.enabled ? "ACTIVE" : "OFF"
          )
        ),
        React.createElement(
          "button",
          {
            type: "button",
            title: "打开完整配置面板",
            onClick: function() {
              if (context.ui && context.ui.openPluginSettings) {
                context.ui.openPluginSettings(context.plugin.id);
              }
            },
            className: "text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 px-2 py-1 rounded-md hover:bg-accent/40 transition-colors"
          },
          "⚙️ 完整设置"
        )
      ),

      // 滚动设置项内容
      React.createElement(
        "div",
        { className: "flex-1 overflow-y-auto p-3 space-y-4" },

        // 1. 一键总开关
        React.createElement(
          "div",
          { className: "flex items-center justify-between p-3 rounded-xl border border-border/60 bg-card/40 hover:bg-card/70 transition-colors" },
          React.createElement(
            "div",
            { className: "space-y-0.5" },
            React.createElement("span", { className: "text-xs font-semibold text-foreground block" }, "毛玻璃与全景透光"),
            React.createElement("p", { className: "text-[11px] text-muted-foreground" }, "开启后编辑器面板全部变成晶莹磨砂透光玻璃")
          ),
          React.createElement(
            "button",
            {
              type: "button",
              onClick: function() { updateField("enabled", !config.enabled); },
              className: "px-3 py-1 rounded-lg text-xs font-semibold transition-all shadow-xs " + (config.enabled ? "bg-primary text-primary-foreground" : "bg-accent/60 text-muted-foreground hover:text-foreground")
            },
            config.enabled ? "已开启" : "已暂停"
          )
        ),

        // 2. 预设精选壁纸推荐网格
        React.createElement(
          "div",
          { className: "space-y-2" },
          React.createElement(
            "div",
            { className: "flex items-center justify-between px-0.5" },
            React.createElement("h4", { className: "text-xs font-semibold text-foreground" }, "🖼️ 精选壁纸一键应用"),
            React.createElement(
              "span",
              { className: "text-[10px] text-muted-foreground font-mono" },
              "4K Curated"
            )
          ),
          React.createElement(
            "div",
            { className: "grid grid-cols-3 gap-2" },
            presetsList.map(function(item) {
              var isSelected = config.bgType === "preset" && config.presetWallpaper === item.id;
              return React.createElement(
                "button",
                {
                  key: item.id,
                  type: "button",
                  onClick: function() {
                    context.config.set("bgType", "preset");
                    context.config.set("presetWallpaper", item.id);
                  },
                  className: "group relative aspect-[16/10] rounded-lg overflow-hidden border transition-all text-left " + (isSelected ? "border-primary ring-2 ring-primary/30 shadow-md" : "border-border/60 hover:border-border")
                },
                item.url ? React.createElement("img", {
                  src: item.url,
                  alt: item.name,
                  className: "size-full object-cover transition-transform duration-300 group-hover:scale-110"
                }) : React.createElement("div", {
                  style: { background: item.gradient },
                  className: "size-full"
                }),
                React.createElement(
                  "div",
                  { className: "absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end p-1.5" },
                  React.createElement(
                    "span",
                    { className: "text-[10px] font-medium text-white truncate drop-shadow-sm" },
                    item.name
                  )
                ),
                isSelected && React.createElement(
                  "span",
                  { className: "absolute top-1 right-1 size-3.5 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-[9px] font-bold shadow-xs" },
                  "✓"
                )
              );
            })
          )
        ),

        // 3. 自定义图片直链输入
        React.createElement(
          "div",
          { className: "p-3 rounded-xl border border-border/60 bg-card/40 space-y-2" },
          React.createElement("label", { className: "text-xs font-semibold text-foreground block" }, "🔗 自定义背景图片 URL"),
          React.createElement(
            "div",
            { className: "flex items-center gap-1.5" },
            React.createElement("input", {
              type: "text",
              value: config.customBgUrl || "",
              onChange: function(e) { updateField("customBgUrl", e.target.value); },
              placeholder: "粘贴以 https:// 开头的图片链接...",
              className: "flex-1 h-8 px-2.5 text-xs rounded-lg bg-accent/20 border border-border/50 outline-none focus:border-primary/60 transition-all font-mono"
            }),
            React.createElement(
              "button",
              {
                type: "button",
                onClick: function() {
                  if (config.customBgUrl && config.customBgUrl.trim()) {
                    context.config.set("bgType", "url");
                    if (context.ui && context.ui.showToast) {
                      context.ui.showToast("已应用自定义背景图片", { type: "success" });
                    }
                  }
                },
                className: "h-8 px-3 text-xs font-semibold bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors shrink-0 shadow-xs"
              },
              "应用"
            )
          )
        ),

        // 4. 即时参数微调滑块 (模糊、透光、亮度)
        React.createElement(
          "div",
          { className: "p-3 rounded-xl border border-border/60 bg-card/40 space-y-3.5" },
          React.createElement("h4", { className: "text-xs font-semibold text-foreground" }, "⚡ 实时视觉微调"),

          // 面板透光度
          React.createElement(
            "div",
            { className: "space-y-1.5" },
            React.createElement(
              "div",
              { className: "flex items-center justify-between text-xs" },
              React.createElement("span", { className: "text-muted-foreground text-[11px]" }, "UI 面板不透明度"),
              React.createElement("span", { className: "font-mono font-medium text-foreground text-[11px]" }, (config.glassOpacity || 55) + "%")
            ),
            React.createElement("input", {
              type: "range",
              min: 15,
              max: 90,
              step: 5,
              value: config.glassOpacity || 55,
              onChange: function(e) { updateField("glassOpacity", parseFloat(e.target.value)); },
              className: "w-full accent-primary h-1.5 bg-accent/60 rounded-lg cursor-pointer"
            })
          ),

          // 玻璃模糊半径
          React.createElement(
            "div",
            { className: "space-y-1.5" },
            React.createElement(
              "div",
              { className: "flex items-center justify-between text-xs" },
              React.createElement("span", { className: "text-muted-foreground text-[11px]" }, "玻璃模糊半径 (Blur)"),
              React.createElement("span", { className: "font-mono font-medium text-foreground text-[11px]" }, (config.glassBlur || 18) + "px")
            ),
            React.createElement("input", {
              type: "range",
              min: 4,
              max: 36,
              step: 2,
              value: config.glassBlur || 18,
              onChange: function(e) { updateField("glassBlur", parseFloat(e.target.value)); },
              className: "w-full accent-primary h-1.5 bg-accent/60 rounded-lg cursor-pointer"
            })
          ),

          // 背景明暗度
          React.createElement(
            "div",
            { className: "space-y-1.5" },
            React.createElement(
              "div",
              { className: "flex items-center justify-between text-xs" },
              React.createElement("span", { className: "text-muted-foreground text-[11px]" }, "全景背景明亮度"),
              React.createElement("span", { className: "font-mono font-medium text-foreground text-[11px]" }, (config.bgBrightness || 55) + "%")
            ),
            React.createElement("input", {
              type: "range",
              min: 15,
              max: 95,
              step: 5,
              value: config.bgBrightness || 55,
              onChange: function(e) { updateField("bgBrightness", parseFloat(e.target.value)); },
              className: "w-full accent-primary h-1.5 bg-accent/60 rounded-lg cursor-pointer"
            })
          )
        )
      )
    );
  }
})();
